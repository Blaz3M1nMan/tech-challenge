from django.apps import AppConfig


class TeApiAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'te_api_app'
