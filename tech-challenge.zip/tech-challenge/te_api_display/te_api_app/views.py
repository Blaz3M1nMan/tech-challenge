from django.shortcuts import render
from django.http import HttpResponse
from . import config
import requests
from requests.auth import HTTPBasicAuth
import re
from json2table import convert

# Variables
TE_API_URL = "https://api.thousandeyes.com/v6/tests.json"
EMAILS_KEYS = config.api_users_keys
PARAMS = {}
AUTHTOKEN = ""
EMAIL = ""
EMAIL_REGEX = r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b"
AUTH = ""
RESPONSE = ""
BUILD_DIRECTION = "LEFT_TO_RIGHT"
TABLE_HEADER = "<table class=\"container\"><thead><tr><th><h1>Parameter " \
               "Name</h1></th><th><h1>Value</h1></th></tr></thead><tbody>"
TABLE_BODY = ""
TABLE_FOOTER = "</tbody></table><br>"
TABLE = ""
ERROR = ""

# Functions
'''
The index function will response with a web page with the instructions to use the TE API call service.
'''
def index(request):
   if request.method == "GET":
      return render(request, "index.html", {"message1": "To use the service go to ", "message2":"/api-request/?email=your-email"})
   else:
      return render(request, "error.html", {"error":"ERROR: Only GET requests supported!"})

'''
The api_call function receives a get request with the parameter email. This function will check whether the
email address is valid and exists in the list of users. If the email address is valid it will pull the authtoken
and will send a request to the TE API.
'''
def api_call(request):
  if request.method == "GET" and "email" in request.GET:
    EMAIL = request.GET["email"].strip()
    count = 0
    if(re.fullmatch(EMAIL_REGEX, EMAIL)):
       for items in EMAILS_KEYS.values():
          if items["email"].strip() == EMAIL:
             AUTHTOKEN = items["authToken"]
             break
       else:
          ERROR = f"ERROR: The email {EMAIL} does not exit on the records!"
          return render(request, "error.html", {"error":ERROR})
       if AUTHTOKEN != "":
          RESPONSE = requests.get(TE_API_URL, auth=(EMAIL, AUTHTOKEN)).json()
          tables = ""
          number_test = 0
          for tests in  RESPONSE['test']:
             TABLE_BODY = convert(tests, build_direction=BUILD_DIRECTION).replace('<table>', '').replace('</table>', '')
             TABLE = TABLE_HEADER + f"<h1>Test Name: {tests['testName']}</h1><br>" + TABLE_BODY + TABLE_FOOTER
             tables += TABLE
             number_test += 1
          return render(request, "results.html", {"number":number_test,"email":EMAIL, "table":tables})
       else:
          ERROR = f"ERROR: This {EMAIL} does not have a valid AUTHTOKEN!"
          return render(request, "error.html", {"error":ERROR})
    else:
       ERROR = f"ERROR: {EMAIL} is not a valid email! Try again."
       return render(request, "error.html", {"error":ERROR})
  else:
    return render(request, "index.html", {"message1": "To use the service go to ", "message2":"/api-request/?email=your-email"})
