#NOTE: You can add as many users as you want.
api_users_keys = {'user_1':{'email':'<your-mail>','authToken':'<your-TE-authToken>'},
                  'user_2':{'email':'<your-mail>','authToken':'<your-TE-authToken>'}}
